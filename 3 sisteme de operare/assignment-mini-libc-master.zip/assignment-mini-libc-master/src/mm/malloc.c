// SPDX-License-Identifier: BSD-3-Clause

#include <internal/mm/mem_list.h>
#include <internal/types.h>
#include <internal/essentials.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>

void *malloc(size_t size)
{
	/* TODO: Implement malloc(). */
    void *mem = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        return NULL;
    }
    mem_list_add(mem, size);

    return mem;
}

void *calloc(size_t nmemb, size_t size)
{
	/* TODO: Implement calloc(). */
    size_t alloc_size = nmemb * size;
    void *mem = malloc(alloc_size);
    if (mem == NULL) {
        return NULL;
    }
    memset(mem, 0, alloc_size);

    return mem;
}

void free(void *ptr)
{
	/* TODO: Implement free(). */
    struct mem_list *list = mem_list_find(ptr);
    munmap(ptr, list->len);
    mem_list_del(ptr);
}

void *realloc(void *ptr, size_t size)
{
	/* TODO: Implement realloc(). */
    struct mem_list *list = mem_list_find(ptr);
    void* mem = mremap(list, list->len, size, MREMAP_MAYMOVE);
    mem_list_del(ptr);
    mem_list_add(mem, size);
    return mem;
}

void *reallocarray(void *ptr, size_t nmemb, size_t size)
{
	/* TODO: Implement reallocarray(). */
    size_t total_size = nmemb * size;
    void *mem = realloc(ptr, total_size);
	return mem;
}
