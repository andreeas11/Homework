// SPDX-License-Identifier: BSD-3-Clause

#include "os_threadpool.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* === TASK === */

/* Creates a task that thread must execute */
os_task_t *task_create(void *arg, void (*f)(void *))
{
	// TODO
	if (arg == NULL)
		return NULL;

	//aloc memorie pt task si il initializez
	os_task_t *t = malloc(sizeof(os_task_t));

	if (t == NULL)
		return NULL;
	t->argument = arg;
	t->task = f;
	return t;
}

/* Add a new task to threadpool task queue */
void add_task_in_queue(os_threadpool_t *tp, os_task_t *t)
{
	// TODO
	//fac nodul nou
	os_task_queue_t *newNode = malloc(sizeof(os_task_queue_t));

	if (newNode == NULL)
		return;

	newNode->next = NULL;
	newNode->task = t;

	//il adaug in lista
	pthread_mutex_lock(&tp->taskLock);
	//daca lista e goala
	if (tp->tasks == NULL) {
		tp->tasks = newNode;
	} else {
		//parcurg lista si adaug la final
		os_task_queue_t *aux = tp->tasks;

		while (aux->next != NULL)
			aux = aux->next;

		aux->next = newNode;
	}
	pthread_mutex_unlock(&tp->taskLock);
}

/* Get the head of task queue from threadpool */
os_task_t *get_task(os_threadpool_t *tp)
{
	// TODO
	pthread_mutex_lock(&tp->taskLock);
	if (tp == NULL) {
		pthread_mutex_unlock(&tp->taskLock);
		return NULL;
	}
	//verific daca lista e goala
	if (tp->tasks == NULL) {
		pthread_mutex_unlock(&tp->taskLock);
		return NULL;
	}

	//scot primul task din lita si-l returnez
	os_task_t *target = tp->tasks->task;

	tp->tasks = tp->tasks->next;
	pthread_mutex_unlock(&tp->taskLock);

	return target;
}

/* === THREAD POOL === */

/* Initialize the new threadpool */
os_threadpool_t *threadpool_create(unsigned int nTasks, unsigned int nThreads)
{
	// TODO
	//aloc memorie si initializez
	os_threadpool_t *threadpool = malloc(sizeof(os_threadpool_t));

	if (!threadpool)
		return NULL;
	threadpool->should_stop = 0;
	threadpool->num_threads = nThreads;
	threadpool->tasks = NULL;

	//initializez mutexul
	pthread_mutex_init(&threadpool->taskLock, NULL);
	//aloc threadurile + create
	threadpool->threads = malloc(nThreads * sizeof(pthread_t));
	for (unsigned int i = 0; i < threadpool->num_threads; i++)
		pthread_create(&threadpool->threads[i], NULL, thread_loop_function, threadpool);

	return threadpool;
}

/* Loop function for threads */
void *thread_loop_function(void *args)
{
	// TODO
	os_threadpool_t *threadpool = (os_threadpool_t *) args;

	while (1) {
		//astept sa iau task din lista si dupa aplic functia
		os_task_t *task = get_task(threadpool);

		if (task != NULL)
			(*(task->task)) (task->argument);

		if (threadpool->should_stop)
			break;
	}
	return NULL;
}

/* Stop the thread pool once a condition is met */
void threadpool_stop(os_threadpool_t *tp, int (*processingIsDone)(os_threadpool_t *))
{
	// TODO
	while (1) {
		//astept ca processingIsDone sa fie 1 si coada de taskuri goala si dupa dau join
		pthread_mutex_lock(&tp->taskLock);
		if (processingIsDone(tp) == 1 && tp->tasks == NULL) {
			tp->should_stop = 1;
			pthread_mutex_unlock(&tp->taskLock);
			for (int i = 0; i < tp->num_threads; i++)
				pthread_join(tp->threads[i], NULL);
			break;
		}
		pthread_mutex_unlock(&tp->taskLock);
	}

	//destroy + free
	pthread_mutex_destroy(&tp->taskLock);
	free(tp->threads);
	free(tp);
}
