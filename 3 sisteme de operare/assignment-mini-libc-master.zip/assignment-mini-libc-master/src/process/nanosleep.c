#include <time.h>
#include <errno.h>

int nanosleep(const struct timespec *req, struct timespec *rem)
{
    /* TODO: Implement nanosleep(). */
    int res = syscall(35, req, rem);
    if (res < 0) {
        errno = -res;
        return -1;
    }

    return res;
}
