// SPDX-License-Identifier: BSD-3-Clause

#include <fcntl.h>
#include <internal/syscall.h>
#include <stdarg.h>
#include <errno.h>

int open(const char *filename, int flags, ...)
{
	/* TODO: Implement open system call. */
    va_list arg;
    va_start(arg, flags);
    long mode = va_arg(arg, long);

    int fd = syscall(__NR_open, filename, flags, mode);
    va_end(arg);
    if (fd < 0) {
        errno = -fd;
        return -1;
    }

    return fd;
}
