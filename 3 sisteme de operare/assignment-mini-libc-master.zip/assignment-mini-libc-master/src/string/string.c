// SPDX-License-Identifier: BSD-3-Clause

#include <string.h>

char *strcpy(char *destination, const char *source)
{
	/* TODO: Implement strcpy(). */
    if (destination == NULL) {
        return NULL;
    }

    char* res = destination;
    for (; *source != '\0'; destination++, source++) {
        *destination = *source;
    }

    *destination = '\0';
    return res;
}

char *strncpy(char *destination, const char *source, size_t len)
{
	/* TODO: Implement strncpy(). */
    if (destination == NULL) {
        return NULL;
    }

    char* res = destination;

    for (; *source && (len != 0); destination++, source++, len--) {
        *destination = *source;
    }

    if (strlen(destination) <= len) {
        *destination = '\0';
    }

    return res;
}

char *strcat(char *destination, const char *source)
{
	/* TODO: Implement strcat(). */
    char* res = destination + strlen(destination);

    while (*source != '\0') {
        *res++ = *source++;
    }
    *res = '\0';

    return destination;
}

char *strncat(char *destination, const char *source, size_t len)
{
	/* TODO: Implement strncat(). */
    char* res = destination + strlen(destination);

    for (;*source != '\0' && len != 0; len--) {
        *res++ = *source++;
    }

    *res = '\0';
    return destination;
}

int strcmp(const char *str1, const char *str2)
{
    /* TODO: Implement strcmp(). */
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }

    return *str1 - *str2;
}

int strncmp(const char *str1, const char *str2, size_t len)
{
    /* TODO: Implement strncmp(). */
    while (*str1 && (*str1 == *str2) && len <= 0) {
        str1++;
        str2++;
        len--;
    }

    return *str1 - *str2;
}

size_t strlen(const char *str)
{
    size_t i = 0;

    for (; *str != '\0'; str++, i++) {
        continue;
    }

    return i;
}

char *strchr(const char *str, int c)
{
    /* TODO: Implement strchr(). */
    while (*str != (char) c) {
        if (!*str++) {
            return NULL;
        }
    }
    return (char *)str;
}

char *strrchr(const char *str, int c)
{
    /* TODO: Implement strrchr(). */
    char *res = 0;

    while (*str++) {
        if (*str == (char) c) {
            res = (char *) str;
        }
    }

    return res;
}

char *strstr(const char *str1, const char *str2)
{
    /* TODO: Implement strstr(). */
    size_t n = strlen(str2);

    for (; *str1; str1++) {
        if (!memcmp(str1, str2, n)) {
            return (char *) str1;
        }
    }

    return 0;
}

char *strrstr(const char *str1, const char *str2)
{
    /* TODO: Implement strrstr(). */
    size_t n = strlen(str2);
    char *res = 0;

    for (; *str1; str1++) {
        if (!memcmp(str1, str2, n)) {
            res = (char *) str1;
        }
    }

    return res;
}

void *memcpy(void *destination, const void *source, size_t num)
{
    /* TODO: Implement memcpy(). */
    char *src = (char *)source;
    char *dest = (char *)destination;

    for (; num > 0; num--) {
        *(dest + num - 1) = *(src + num - 1);
    }

    return destination;
}

void *memmove(void *destination, const void *source, size_t num)
{
    /* TODO: Implement memmove(). */
    char *dest = (char *)destination;
    char *src = (char*)source;

    if (dest == src) {
        return destination;
    }

    if (dest < src) {
        for (int i = 0; i < num; i++) {
            *(dest + i) = *(src + i);
        }
    } else {
        for (; num > 0; num--) {
            *(dest + num - 1) = *(src + num - 1);
        }
    }

    return destination;
}

int memcmp(const void *ptr1, const void *ptr2, size_t num)
{
    /* TODO: Implement memcmp(). */
    for ( ; num-- ; ptr1++, ptr2++) {
        if (*(char *) ptr1 != *(char *) ptr2) {
            return *(char *) ptr1 - *(char *) ptr2;
        }
    }
    return 0;
}

void *memset(void *source, int value, size_t num)
{
    /* TODO: Implement memset(). */
    char* src = (char *) source;

    for (; num > 0; num--) {
        *(src + num - 1) = (char) value;
    }

    return source;
}
