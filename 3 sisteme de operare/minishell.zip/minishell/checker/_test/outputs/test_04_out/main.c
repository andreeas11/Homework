#include <stdio.h>
int main(void) {
fprintf(stderr, "test_err\n");
fprintf(stdout, "test_out\n");
return 0;
}
