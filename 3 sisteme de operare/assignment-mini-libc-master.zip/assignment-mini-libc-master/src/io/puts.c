#include <fcntl.h>
#include <internal/syscall.h>
#include <stdio.h>
#include <errno.h>

int puts(const char * str)
{
    /* TODO: Implement puts(). */

    int nr = 0;
    for (; *str != '\0'; str++, nr++) {
        if (write(1, str, 1) != 1) {
            return EOF;
        }
    }

    if (write(1, "\n", 1) != 1) {
        return EOF;
    }
    nr++;

    return nr;
}
