// SPDX-License-Identifier: BSD-3-Clause

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "cmd.h"
#include "utils.h"

#define READ		0
#define WRITE		1

/**
 * Internal change-directory command.
 */

// inspiratie din lab si curs

static bool shell_cd(word_t *dir, int fd)
{
	/* TODO: Execute cd. */
	char *path = malloc(1000);

	path = get_word(dir);
	if (!path)
		return -1;

	if (chdir(path) < 0)
		return -1;

	free(path);
	return 0;
}

static bool shell_pwd(int fd)
{
	char *buff = malloc(1000);
	char *p = getcwd(buff, 1000);

	if (!p)
		return 0;
	dprintf(fd, "%s\n", buff);
	free(buff);
	return 0;
}

/**
 * Internal exit/quit command.
 */
static int shell_exit(void)
{
	/* TODO: Execute exit/quit. */

	return SHELL_EXIT	; /* TODO: Replace with actual exit code. */
}

/**
 * Parse a simple command (internal, environment variable assignment,
 * external command).
 */
static int parse_simple(simple_command_t *s, int level, command_t *father)
{
	/* TODO: Sanity checks. */

	/* TODO: If builtin command, execute the command. */
	char *comm = malloc(1000);
	char *out_file = get_word(s->out);
	char *err_file = get_word(s->err);
	int fd;

	int *nr = malloc(sizeof(int));
	char **args = get_argv(s, nr);

	comm = get_word(s->verb);
	if (!comm)
		return -1;
	if (!strcmp(comm, "pwd")) { //pwd
		if (!s->out)
			return shell_pwd(1); // stdout
		if (s->io_flags & IO_OUT_APPEND)
			fd = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		else
			fd = open(out_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
		return shell_pwd(fd);
	} else if (!strcmp(comm, "cd")) { // cd
		if (*nr > 2)
			return -1;
		if (!s->out)
			return shell_cd(s->params, 1); // stdout
		if (s->out) {
			fd = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			return shell_cd(s->params, fd);
		}
	} else if (!strcmp(comm, "exit") || !strcmp(comm, "quit")) { //exit sau quit
		return shell_exit();
	}
	close(fd);

	/* TODO: If variable assignment, execute the assignment and return
	 * the exit status.
	 */
	if (s->verb->next_part)
		return setenv(s->verb->string, get_word(s->verb->next_part->next_part), 1);


	/* TODO: If external command:
	 *   1. Fork new process
	 *     2c. Perform redirections in child
	 *     3c. Load executable in child
	 *   2. Wait for child
	 *   3. Return exit status
	 */

	int pid = fork();
	int status;
	pid_t wait_ret;
	int fd1, fd2;
	int both = 0;

	switch (pid) {
	case -1:
		DIE(1, "fork");
		break;

	case 0:
		/* Child process */
		if (s->in) { // <
			fd1 = open(get_word(s->in), O_RDONLY);
			dup2(fd1, 0);
			DIE(fd1 < 0, "dup2");
			close(fd1);
		}
		if (s->out) {
			if (s->err && !strcmp(err_file, out_file) && (!(s->io_flags & IO_OUT_APPEND)
			&& !(s->io_flags & IO_ERR_APPEND))) { // &>
				both = 1;
				// pentru prima va fi cu trunc
				fd1 = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
				fd2 = dup2(fd1, 2);
				DIE(fd1 < 0, "dup2");
				fd2 = close(fd1);
				DIE(fd2 < 0, "close");
				// pentru a doua va fi cu append (trebuie sa adauge la ce s-a pus inainte
				fd1 = open(out_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
				fd2 = dup2(fd1, 1);
				DIE(fd1 < 0, "dup2");
				fd2 = close(fd1);
				DIE(fd2 < 0, "close");
			} else {
				if (s->io_flags & IO_OUT_APPEND) // >>
					fd1 = open(out_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
				else // >
					fd1 = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);

				fd2 = dup2(fd1, 1);
				DIE(fd1 < 0, "dup2");
				fd2 = close(fd1);
				DIE(fd2 < 0, "close");
			}

		}
		if (s->err && !both) {
			if (s->io_flags & IO_ERR_APPEND) // 2>>
				fd1 = open(err_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
			else // 2>
				fd1 = open(err_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);

			fd2 = dup2(fd1, 2);
			DIE(fd1 < 0, "dup2");
			fd2 = close(fd1);
			DIE(fd2 < 0, "close");
		}

		// executa comanda
		execvp(args[0], (char *const *) args);
		break;

	default:
		/* Parent process */
		wait_ret = waitpid(pid, &status, 0);
		DIE(wait_ret < 0, "waitpid");
	}

	return status; /* TODO: Replace with actual exit status. */
}

/**
 * Process two commands in parallel, by creating two children.
 */
static bool run_in_parallel(command_t *cmd1, command_t *cmd2, int level,
		command_t *father)
{
	/* TODO: Execute cmd1 and cmd2 simultaneously. */
	int pid = fork();
	pid_t wait_ret;
	int res;
	// se executa in paralel => child + parent
	switch (pid) {
	case -1:
		DIE(1, "fork");
		break;

	case 0:
		/* Child process */
		parse_command(cmd1, level, father);
		exit(0);

	default:
		/* Parent process */
		res = parse_command(cmd2, level, father);
	}

	return res; /* TODO: Replace with actual exit status. */
}

/**
 * Run commands by creating an anonymous pipe (cmd1 | cmd2).
 */
static bool run_on_pipe(command_t *cmd1, command_t *cmd2, int level,
		command_t *father)
{
	/* TODO: Redirect the output of cmd1 to the input of cmd2. */

	return true; /* TODO: Replace with actual exit status. */
}

/**
 * Parse and execute a command.
 */
int parse_command(command_t *c, int level, command_t *father)
{
	/* TODO: sanity checks */

	if (c->op == OP_NONE) {
		/* TODO: Execute a simple command. */
		return parse_simple(c->scmd, level, father); /* TODO: Replace with actual exit code of command. */
	}

	int res;

	switch (c->op) {
	case OP_SEQUENTIAL:
		/* TODO: Execute the commands one after the other. */
		parse_command(c->cmd1, level, father);
		res = parse_command(c->cmd2, level, father);
		return res;

	case OP_PARALLEL:
		/* TODO: Execute the commands simultaneously. */
		return run_in_parallel(c->cmd1, c->cmd2, level + 1, c);

	case OP_CONDITIONAL_NZERO:
		/* TODO: Execute the second command only if the first one
		 * returns non zero.
		 */
		res = parse_command(c->cmd1, level, c);
		if (res)
			res = parse_command(c->cmd2, level, c);
		return res;

	case OP_CONDITIONAL_ZERO:
		/* TODO: Execute the second command only if the first one
		 * returns zero.
		 */
		res = parse_command(c->cmd1, level, c);
		if (!res)
			res = parse_command(c->cmd2, level, c);
		return res;

	case OP_PIPE:
		/* TODO: Redirect the output of the first command to the
		 * input of the second.
		 */

		break;

	default:
		return SHELL_EXIT;
	}

	return 0; /* TODO: Replace with actual exit code of command. */
}
