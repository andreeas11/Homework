// SPDX-License-Identifier: BSD-3-Clause

#include "osmem.h"
#include "helpers.h"

struct block_meta *meta_list_head;

void *heap_start;

void split(struct block_meta *block, size_t size)
{
	if (block->size >= ALIGN(size) + ALIGN(sizeof(struct block_meta)) + 8) {
		struct block_meta *new_block = (struct block_meta *)((void *) block + ALIGN(sizeof(struct block_meta)) + ALIGN(size));

		new_block->size = block->size - ALIGN(size) - ALIGN(sizeof(struct block_meta));
		new_block->status = STATUS_FREE;
		new_block->next = block->next;

		block->size = ALIGN(size);
		block->status = STATUS_ALLOC;
		block->next = new_block;
	}
}

void coalesce(void)
{
	struct block_meta *aux = heap_start;

	while (aux->next) {
		if (aux->status == STATUS_FREE && aux->next->status == STATUS_FREE) {
			aux->size += aux->next->size + ALIGN(sizeof(struct block_meta));
			aux->next = aux->next->next;
		} else {
			aux = aux->next;
		}
	}
}

void *os_alloc(size_t size, size_t treshold)
{
	struct block_meta *block;

	if (size <= 0) {
		return NULL;
	} else if (ALIGN(size) + ALIGN(sizeof(struct block_meta)) >= treshold) {
		// mmap for large blocks
		block = mmap(NULL, ALIGN(size) + ALIGN(sizeof(struct block_meta)), PROT_READ | PROT_WRITE,
				MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
		if (block == MAP_FAILED)
			return NULL;
		block->size = ALIGN(size);
		block->status = STATUS_MAPPED;
		return (void *) block + ALIGN(sizeof(struct block_meta));
	}
	if (heap_start == NULL) {
		block = sbrk(MYMMAP_THRESHOLD);
		if (block == (void *) -1)
			return NULL;
		block->size = MYMMAP_THRESHOLD - ALIGN(sizeof(struct block_meta));
		block->status = STATUS_ALLOC;
		block->next = NULL;
		heap_start = block;
		split(block, size);
		return (void *) block + ALIGN(sizeof(struct block_meta));
	}
	coalesce();
	//caut cel mai bun loc liber
	struct block_meta *aux = heap_start, *best = NULL;

	while (aux->next) {
		if (aux->size >= ALIGN(size) && aux->status == STATUS_FREE && (best == NULL || best->size > aux->size))
			best = aux;
		aux = aux->next;
	}
	if (aux->status == STATUS_FREE) {
		if (best != NULL) {
			if (best->size > aux->size && aux->size >= ALIGN(size)) {
				aux->status = STATUS_ALLOC;
				split(aux, size);
				return (void *) aux + ALIGN(sizeof(struct block_meta));
			}
			best->status = STATUS_ALLOC;
			split(best, size);
			return (void *) best + ALIGN(sizeof(struct block_meta));
		}
		// daca best e NULL
		if (aux->size >= ALIGN(size)) {
			aux->status = STATUS_ALLOC;
			split(aux, size);
			return (void *) aux + ALIGN(sizeof(struct block_meta));
		}
		size_t toAlloc = ALIGN(size) - aux->size;
		struct block_meta *extra = sbrk(toAlloc);

		if (extra == (void *) -1)
			return NULL;
		aux->size = ALIGN(size);
		aux->status = STATUS_ALLOC;
		aux->next = NULL;
		return (void *) aux + ALIGN(sizeof(struct block_meta));
	}
	if (best != NULL) {
		best->status = STATUS_ALLOC;
		split(best, size);
		return (void *) best + ALIGN(sizeof(struct block_meta));
	}
	block = sbrk(ALIGN(size) + ALIGN(sizeof(struct block_meta)));
	if (block == (void *) -1)
		return NULL;
	aux->next = block;
	block->size = ALIGN(size);
	block->status = STATUS_ALLOC;
	block->next = NULL;
	return (void *) block + ALIGN(sizeof(struct block_meta));
}


void *os_malloc(size_t size)
{
	/* TODO: Implement os_malloc */
	return os_alloc(size, MYMMAP_THRESHOLD);
}

void os_free(void *ptr)
{
	/* TODO: Implement os_free */
	if (!ptr)
		return;

	struct block_meta *l = ((void *) ptr - ALIGN(sizeof(struct block_meta)));

	if (l->status == STATUS_MAPPED)
		munmap(l, l->size + ALIGN(sizeof(struct block_meta)));
	else if (l->status == STATUS_ALLOC)
		l->status = STATUS_FREE;
}

void *os_calloc(size_t nmemb, size_t size)
{
	/* TODO: Implement os_calloc */
	void *p = os_alloc(nmemb * size, getpagesize());

	memset(p, 0, nmemb * size);
	return p;
}

void *os_realloc(void *ptr, size_t size)
{
	/* TODO: Implement os_realloc */
	if (ptr == NULL)
		return os_malloc(size);
	if (size == 0) {
		os_free(ptr);
		return NULL;
	}
	struct block_meta *l = ((void *) ptr - ALIGN(sizeof(struct block_meta)));

	if (l->status == STATUS_FREE)
		return NULL;
	if (l->status == STATUS_MAPPED) {
		void *newptr = os_malloc(size);

		if (newptr == NULL)
			return NULL;
		//memcpy
		if (ALIGN(size) > l->size)
			memcpy(newptr, ptr, l->size);
		else
			memcpy(newptr, ptr, ALIGN(size));

		os_free(ptr);
		return (void *) newptr;
	}
	// status == alloc
	if (ALIGN(size) <= l->size) {
		split(l, size);
		return (void *) l + ALIGN(sizeof(struct block_meta));
	}
	coalesce();

	// daca e last
	if (l->next == NULL) {
		size_t toAlloc = ALIGN(size) - l->size;
		struct block_meta *extra = sbrk(toAlloc);

		if (extra == (void *) -1)
			return NULL;
		l->size = ALIGN(size);
		l->next = NULL;
		return (void *) l + ALIGN(sizeof(struct block_meta));
	}

	// verific daca urm sunt free si pot sa l unesc cu ele (cat am nevoie)
	if (l->next->status == STATUS_FREE) {
		if (l->size + l->next->size + ALIGN(sizeof(struct block_meta)) >= ALIGN(size)) {
			l->size += l->next->size + ALIGN(sizeof(struct block_meta));
			l->next = l->next->next;
			split(l, ALIGN(size));
			return (void *) l + ALIGN(sizeof(struct block_meta));
		}
	}

	void *newptr = os_malloc(size);

	if (newptr == NULL)
		return NULL;
	//memcpy
	memcpy(newptr, ptr, l->size);
	os_free(ptr);
	return (void *) newptr;
}
