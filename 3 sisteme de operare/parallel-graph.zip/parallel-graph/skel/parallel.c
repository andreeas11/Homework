// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

#include "os_graph.h"
#include "os_threadpool.h"

#define MAX_TASK 100
#define MAX_THREAD 4

int sum;
os_graph_t *graph;
os_threadpool_t *threadpool;
pthread_mutex_t *sumLock, *visitedLock;

//functia pentru oprit
int isReady(os_threadpool_t *t)
{
	//verifica daca toate nodurile au fost vizitate
	pthread_mutex_lock(visitedLock);
	for (int i = 0; i < graph->nCount; i++) {
		//daca inca sunt noduri nevizitate => 0 altfel 1
		if (graph->visited[i] == 0) {
			pthread_mutex_unlock(visitedLock);
			return 0;
		}
	}
	pthread_mutex_unlock(visitedLock);
	return 1;
}

void processNode(void *arg)
{
	//asemanator cu codul din serial + sincronizare
	unsigned int nodeIdx = *((unsigned int *) (arg));
	os_node_t *node = graph->nodes[nodeIdx];

	//pentru suma => mutex
	pthread_mutex_lock(sumLock);
	sum += node->nodeInfo;
	pthread_mutex_unlock(sumLock);

	for (int i = 0; i < node->cNeighbours; i++) {
		pthread_mutex_lock(visitedLock);
		if (graph->visited[node->neighbours[i]] == 0) {
			graph->visited[node->neighbours[i]] = 1;
			unsigned int *sent_task = malloc(sizeof(unsigned int));
			*sent_task = node->neighbours[i];
			//adaug in coada taskul
			os_task_t *task = task_create((void *) sent_task, processNode);

			add_task_in_queue(threadpool, task);
		}
		pthread_mutex_unlock(visitedLock);
	}
}

void traverse_graph(void)
{
	//asemanator cu codul din serial + sincronizare
	for (int i = 0; i < graph->nCount; i++) {
		pthread_mutex_lock(visitedLock);
		if (graph->visited[i] == 0) {
			graph->visited[i] = 1;
			unsigned int *sent_task = malloc(sizeof(unsigned int));
			*sent_task = i;
			//adaug in coada taskul
			os_task_t *task = task_create((void *) sent_task, processNode);

			add_task_in_queue(threadpool, task);
		}
		pthread_mutex_unlock(visitedLock);
	}
}


int main(int argc, char *argv[])
{
	if (argc != 2) {
		printf("Usage: ./%s input_file\n", __func__);
		exit(1);
	}

	FILE *input_file = fopen(argv[1], "r");

	if (input_file == NULL) {
		printf("[Error] Can't open file\n");
		return -1;
	}

	graph = create_graph_from_file(input_file);
	if (graph == NULL) {
		printf("[Error] Can't read the graph from file\n");
		return -1;
	}

	// TODO: create thread pool and traverse the graf
	//initializere mutexuri + creare threadpool
	sumLock = malloc(sizeof(pthread_mutex_t));
	visitedLock = malloc(sizeof(pthread_mutex_t));
	pthread_mutex_init(sumLock, NULL);
	pthread_mutex_init(visitedLock, NULL);
	threadpool = threadpool_create(MAX_TASK, MAX_THREAD);

	//traversare graf + suma noduri
	traverse_graph();

	//oprire threadpool
	threadpool_stop(threadpool, isReady);

	//distrugere mutexuri
	pthread_mutex_destroy(sumLock);
	pthread_mutex_destroy(visitedLock);

	printf("%d", sum);
	return 0;
}

